/*1. Write a C program which can input five students marks in
three courses and display the average marks of each student.*/

#include<stdio.h>
#include<math.h>

int main()
{
    int c,r,x[5][3],s;
    for(r=0;r<5;r++){
            printf("Enter student no %d marks:\n",r+1);
        for(c=0;c<3;c++){
            scanf("%d",&x[r][c]);
        }
    }

    for(r=0;r<5;r++){
    s=0;
        for(c=0;c<3;c++){
           s=s+x[r][c];
        }

    printf("student no %d average marks %.2f\n",r+1,s/3.0);
    }
}

