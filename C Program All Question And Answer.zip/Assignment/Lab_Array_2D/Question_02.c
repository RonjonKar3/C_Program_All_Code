/*2. Write a C program which can input five students marks in three courses
and display whether student pass in all courses (60 is pass marks)*/

#include<stdio.h>
#include<math.h>

int main()
{
    int c,r,x[5][3],m=0,n=0;
    for(r=0;r<5;r++){
    printf("Enter student no %d marks in three courses\n",r+1);
        for(c=0;c<3;c++){
            scanf("%d",&x[r][c]);
        }
    }
     printf("The Output is:\n");
    for(r=0;r<5;r++){
    m=0;
       for(c=0;c<3;c++){
        if(x[r][c]>=60){
            m++;
        }
        else {
            n++;
        }
        }

        if(m==3){
            printf("Yes\n");
           }
           else{
            printf("No\n");
           }
    }
}




