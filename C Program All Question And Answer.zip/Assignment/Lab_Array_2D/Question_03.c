/*3. Write a C program which can four cities temperature for last five days and
display in how many days for each city temperature is higher than previous day*/

#include<stdio.h>
int main()
{
    int x[4][5],r,c,d;
    for(r=0;r<4;r++){
    printf("Enter city no:%d temperature for last five days:\n",r+1);
        for(c=0;c<5;c++){
            scanf("%d",&x[r][c]);
        }
    }
    for(r=0;r<4;r++){
        d=0;
        for(c=1;c<5;c++){
           if(x[r][c]>x[r][c-1]){
            d++;
           }
        }
    printf("%d days for each city temperature is higher than previous day:\n",d);
    }
}
