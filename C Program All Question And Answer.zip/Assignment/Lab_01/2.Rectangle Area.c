//2

#include<stdio.h>
#include<math.h>
int main(){
float l,b,area;
scanf ("%f",&l);
scanf ("%f",&b);
area= l*b;
printf ("%.2f",area);
return 0;
}
