//Question_12

#include<stdio.h>
int main(){
float a,Ans;
printf("Enter the Length of a Book in centimeter scale:\n");
scanf("%f",&a);
Ans=a*(1/2.54);
printf("length of that book in inch scale=%.2f\n",Ans);
return 0;
}

