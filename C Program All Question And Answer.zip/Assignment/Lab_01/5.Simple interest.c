//5

#include<stdio.h>
#include<conio.h>
int main(){
    float p,r,t,si;
    scanf("%f%f%f",&p,&r,&t);
    si=p*r*t/100;
    printf("%f",si);
return 0;
}
