//9

#include<stdio.h>
#include<math.h>
int main(){
float km,m,feet,inch,cm;
scanf("%f",&km);
m=km*1000;
feet=km*3280.84;
inch=km*39370.0787;
cm=km*100000;
printf("Meter=%.2f\n",m);
printf("Feet=%.2f\n",feet);
printf("Inches=%.2f\n",inch);
printf("Centimeter=%.2f\n",cm);
return 0;
}
