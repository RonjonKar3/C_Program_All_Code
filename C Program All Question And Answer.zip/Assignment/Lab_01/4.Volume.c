//4

#include<stdio.h>
#include<math.h>
int main(){
float r,h,volume;
scanf("%f",&r);
scanf("%f",&h);
volume=3.14*r*r*h;
printf("%f",volume);
return 0;
}
