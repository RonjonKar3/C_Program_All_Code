//3

#include<stdio.h>
#include<math.h>
int main(){
float r,area,circumference;
scanf("%f",&r);
area=3.14*r*r;
circumference= 2*3.14*r;
printf("%f\n",area);
printf("%f",circumference);
return 0;
}
