//17

#include<stdio.h>
#include<math.h>
int main(){
int a,b,c;
float s,Area;
scanf("%d%d%d",&a,&b,&c);
s =(a+b+c)/2;
Area = sqrt(s*(s-a)*(s-b)*(s-c));
printf("%.2f\n",s);
printf("%.2f\n",Area);
return 0;
}


