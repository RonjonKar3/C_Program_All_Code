//Question_14

#include<stdio.h>
#include<math.h>
int main()
{
int Hours,Minutes;
float FractionalHours,FractionalMinutes;
scanf("%d%d",&Hours,&Minutes);
FractionalHours=(Hours+(Minutes/60.0));
FractionalMinutes=Hours*60+Minutes;
printf("%.2f\n",FractionalHours);
printf("%.2f\n",FractionalMinutes);
return 0;
}




