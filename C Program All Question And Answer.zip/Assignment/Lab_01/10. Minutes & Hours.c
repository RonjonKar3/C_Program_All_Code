/*10. Write a program to Input minutes and convert in hours and minutes.*/

#include<stdio.h>
#include<math.h>
int main()
{
    float min,m,h;
    scanf("%f",&min);
    h= min/60.0;
    m= min/1.0;
    printf("%.2f\n%.2f",h,m);
}

