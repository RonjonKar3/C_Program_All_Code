//11

#include<stdio.h>
#include<math.h>
 int main() {
float Day, years, months,weeks, days;
scanf("%f",&Day);
years=Day/365;
months=Day/30;
weeks=Day/7;
days=Day;
printf("%f\n",years);
printf("%f\n",months);
printf("%f\n",weeks);
printf("%f\n",days);
return 0;
}

