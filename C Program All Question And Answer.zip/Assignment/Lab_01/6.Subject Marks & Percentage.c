//6

#include<stdio.h>
int main(){
int Bangla,English,Math,Physics,Chemistry;
float Marks, Percentage;
scanf("%d%d%d%d%d",&Bangla,&English,&Math,&Physics,&Chemistry);
Marks=Bangla+English+Math+Physics+Chemistry;
Percentage=(Marks/500)*100;
printf("%f\n",Marks);
printf("%f\n",Percentage);
return 0;
}


