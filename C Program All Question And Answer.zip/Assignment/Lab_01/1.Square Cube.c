//1

#include<stdio.h>
#include<math.h>
int main(){
int x,square,cube;
scanf ("%d",&x);
square=x*x;
cube=x*x*x;
printf ("%d\n",square);
printf ("%d",cube);
return 0;
}
