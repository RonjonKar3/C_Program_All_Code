//13

#include <stdio.h>
int main()
{
int radius_of_sphere_shaped,length_of_cubic_shaped;
float volume_of_sphere_shaped,volume_of_cubic_shaped;

scanf("%d",&radius_of_sphere_shaped);
scanf("%d",&length_of_cubic_shaped);

volume_of_sphere_shaped=(4/3.0)*3.14*radius_of_sphere_shaped*radius_of_sphere_shaped*radius_of_sphere_shaped;
printf("\n%.2f",volume_of_sphere_shaped);


volume_of_cubic_shaped=length_of_cubic_shaped*length_of_cubic_shaped*length_of_cubic_shaped;
printf("\n%0.2f\n",volume_of_cubic_shaped);

return 0;
}


