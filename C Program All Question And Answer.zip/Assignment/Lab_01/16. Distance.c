//Question_16

#include<stdio.h>
#include<math.h>
int main(){
int x1,y1,x2,y2;
float Ans;
printf("Enter four integer numbers that indicated two points in a 2D co-ordinate system\n");
scanf("%d%d%d%d",&x1,&y1,&x2,&y2);
Ans=sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2));
printf("The distance between those two points=%0.2f\n",Ans);
return 0;
}



