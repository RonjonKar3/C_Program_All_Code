//15

#include<stdio.h>
#include<math.h>

int main(){
float A,B,C,D,Ratio;
scanf("%f%f%f%f",&A,&B,&C,&D);
Ratio=(A-B)/(C-D);
printf("Value of Ratio=%.2f\n",Ratio);
return 0;
}

