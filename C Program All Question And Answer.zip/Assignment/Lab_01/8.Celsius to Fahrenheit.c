//8

#include<stdio.h>
int main(){
float F,C;
scanf("%f",&C);
F=(C*9)/5+32;
printf("%f\n",F);
return 0;
}
