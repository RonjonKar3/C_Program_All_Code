/*8. Write a C program which can input last seven days temperature into an array and display the highest
temperature. How many days that highest is found*/

#include<stdio.h>
int main()
{
    int i,c=0,max;

    int a[7];
      printf("Enter last seven days temperature:\n");
    for(i=0;i<7;i++){
      scanf("%d",&a[i]);
    }

    for(i=0;i<7;i++){
        if(a[i]>max){
            max=a[i];
        }
    }
    for(i=0;i<7;i++){
        if(max==a[i]){
            c++;
        }
    }
    printf("Highest temperature is: %d\n",max);
    printf("Highest is found %d days.",c);
    return 0;

}
