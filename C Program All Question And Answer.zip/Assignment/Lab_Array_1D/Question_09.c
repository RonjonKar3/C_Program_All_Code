/*9. Write a C program which can input some persons� age into an array and display how many of them 
are older than average age of those persons*/

#include<stdio.h>
int main()
{
    int x[100],c=0,s=0,i,avg,n;
    scanf("%d",&n);
    for (i=0;i<n;i++){
        scanf("%d",&x[i]);
    }
    for (i=0;i<n;i++){
        s=s+x[i];
        avg=s/n;
        if(x[i]>avg){
            c++;
        }
    }

    printf("%d",c);

}
