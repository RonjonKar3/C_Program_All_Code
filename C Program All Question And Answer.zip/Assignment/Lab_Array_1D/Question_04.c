/*4. Write a C program which can input last seven days temperature and display in how many days the 
temperature is increased than that of immediate previous day*/

#include<stdio.h>
int main()
{
    int i,c=0,t[20];
    for (i=1;i<=7;i++){
        scanf("%d",&t[i]);
    }

    for (i=1;i<=6;i++){
            if (t[i]>t[i+1]){
                c++;
            }
     }
         printf("%d",c);
}
