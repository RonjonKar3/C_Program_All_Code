/*5. Write a C program which can input last seven days temperature and display in how many days the 
temperature is increased by at least 3 degree from the previous day.*/

#include<stdio.h>
int main()
{
    int x[100],i,c=0,s=0,n;
    scanf("%d",&n);
    for(i=0;i<6;i++){
        scanf("%d",&x[i]);
    }
    for(i=1;i<7;i++){
        if(x[i]>x[i-1])
        if(x[i]-x[i-1]>=3){
            c++;
        }
    }
    printf("%d",c);
}
