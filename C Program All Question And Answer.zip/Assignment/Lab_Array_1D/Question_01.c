/*1. Write a C program which can input last seven days
temperature into an array and display the average temperature.*/

#include<stdio.h>
int main()
{
    int i,s=0,t[20];
    float avg,c=0;
    printf("Enter last seven days temperature:\n");

    for(i=1;i<=7;i++){
        scanf("%d",&t[i]);
        s=s+t[i];
        c++;
    }
    avg = s/c;
    printf("The the average temperature: %f",avg);
}
