/*7. Write a C program which can some 2D points into an array (The x values in one array and y values in 
another array). Display how many points are in each quadrant*/

#include<stdio.h>
int main()
{
    int i,x[100],y[100],c=0,d=0,e=0,f=0,n;
    scanf("%d",&n);
    printf("Enter Some 2D Points: \n");
    for(i=0;i<n;i++){
        scanf("%d%d",&x[i],&y[i]);
    }
    for(i=0;i<n;i++){
    if(x[i]>0 && y[i]>0){
       c++;
    }
    if(x[i]<0 && y[i]>0){
       d++;
    }
    if(x[i]<0 && y[i]<0){
       e++;
    }
     if(x[i]>0 && y[i]<0){
       f++;
    }
    }
printf("1St :%d\n",c);
printf("2nd :%d\n",d);
printf("3rd :%d\n",e);
printf("4th :%d\n",f);
}
