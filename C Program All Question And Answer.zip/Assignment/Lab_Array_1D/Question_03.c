/*3. Write a C program which can input some students' CGPA of a particular class into an array and check
whether there is any student with perfect CGPA (i.e. CGPA 4.00).*/

#include<stdio.h>
int main()
{
    int n,i,c=0;
     float a[100];
    scanf("%d",&n);
    printf("Enter Some Student's CGPA: ");

    for (i=0;i<n;i++){
        scanf("%f",&a[i]);
    }
    for (i=0;i<n;i++){
        if(a[i]==4.00){
         printf("Yes");
        }
    }

}

