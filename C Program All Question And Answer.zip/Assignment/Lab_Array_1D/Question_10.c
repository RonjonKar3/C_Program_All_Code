/*10. Write a C program which can input some students� marks and display which grades are achieved by
most of the students (Grades are A, B, C, and D).*/

#include<stdio.h>
int main()
{
    int i,x[100],n,a,b,c,d;
    scanf("%d",&n);
    printf("Enter Some Students Mark: \n");
    a=0;
    b=0;
    c=0;
    d=0;
    for (i=0; i<n; i++){
        scanf("%d",&x[i]);
    }
    for (i=0; i<n; i++){
        if(x[i]>=97){
           a++;
        }
        if(x[i]>=80 && x[i]<97){
            b++;
        }
        if(x[i]>=70 && x[i]<80){
            c++;
        }
        if(x[i]<70){
            d++;
        }
    }
    if(a>b || a>c ||a>d){
        printf("A");
    }
     if(b>a || b>c ||b>d){
        printf("B");
    }
     if(c>a || c>b ||c>d){
        printf("C");
    }
     if(d>a || d>b ||d>c){
        printf("D");
    }
}
