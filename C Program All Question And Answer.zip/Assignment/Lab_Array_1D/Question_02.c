/*2. Write a C program which can input some students' age of a particular class into an array and display 
how many of them are teenager in that class.*/

#include<stdio.h>
int main ()
{
    int a,x[50],n,T;
printf("Enter Some Students Ages:\n");
    scanf("%d",&n);
    T=0;
    for (a=1;a<=n;a++){
       scanf("%d",&x[a]);


    if(x[a]>=13 && x[a]<=19){
            T++;
       }
    }
    printf("Teenage: %d\n",T);

}

