/*4. Write a C program which can take input of some students marks and display how many students�
score is within 10% of average marks*/

#include<stdio.h>
int main()
{
    int i,n,x[100],s=0,m,c=0;
    float avg;
    printf("Enter the value of n: ");
    scanf("%d",&n);
    for(i=0;i<n;i++){
         printf("Enter the Marks of Student no %d: ",i+1);
        scanf("%d",&x[i]);
    }
    for(i=0;i<n;i++){
    s = s+x[i];
    }
    avg=s/n;
    m= avg*0.1;
    for(i=0;i<n;i++){
        if(x[i]<= m){
            c++;
        }

    }
     printf("%d students",c);
}


