/*2. Write a C program which can take input some student�s number into an array and find out if the
number of students passed is double of the number of students failed.*/

#include<stdio.h>
int main()
{
    int x[100],i,n,p,f;
    printf("Enter the value of n:\n");
    scanf("%d",&n);
    printf("Enter the Some Students Number:\n");
    for (i=0;i<n;i++){
        scanf("%d",&x[i]);
    }
    p=0;
    f=0;
    for (i=0;i<n;i++){
       if(x[i]>=60){
        p++;
       }
       else if(x[i]<60) {
        f++;
       }
    }
    if(p==2*f){
     printf("The number of students passed is double of the number of students failed");
    }
    else{
	printf("The number of students passed is not double of the number of students failed");
}

}





