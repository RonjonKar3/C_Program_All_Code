#include<stdio.h>
int main()
{
    int i,a,b,n,x[100],c=0;
    printf("Enter the value of n: ");
    scanf("%d",&n);
    printf("Enter %d numbers: ",n);
    for(i=0;i<n;i++){
        scanf("%d",&x[i]);
    }
    for(a=0;a<n;a++){
            c=0;
    for(b=a+1;b<n;b++){
        if(x[b]>x[a]){
            c++;
        }
    }
        printf("The number of value bigger than the next number: %d\n",c);

    }
}
