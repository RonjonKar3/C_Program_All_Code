/*11. Write a C program which can input some students' marks and check whether any student got full
marks. You may assume that exam's total mark is 30*/
#include<stdio.h>
int main()
{
    int x[100],n,i,c=0;
    printf("Enter the value of n: ");
    scanf("%d",&n);
    printf("Enter some students marks which will not more than 30: \n");
    for(i=0;i<n;i++){
      scanf("%d",&x[i]);
    }
    for(i=0;i<n;i++){
        if(x[i]==30){
            c++;
        printf("Yes\n");
        }
    }
    printf("%d student got full marks",c);
}
