/*3. Write a C program which can take input of some numbers into an array and display the highest
number.*/

#include<stdio.h>
int main()
{
    int i,n,x[100];
    printf("Enter the value of n: ");
    scanf("%d",&n);
    for(i=0;i<n;i++){
         printf("Enter the number %d: ",i+1);
        scanf("%d",&x[i]);
    }
    for (i=0;i<n;i++){
        if(x[i]>x[0]){
        x[0]=x[i];
        }
    }
     printf("The Highest Number is: %d",x[0]);
}
