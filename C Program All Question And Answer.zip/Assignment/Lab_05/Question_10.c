/*10. Recently you bought some chocolates and randomly make some packet with those chocolates
(each of those packets consists of at least two chocolates). However, after making the chocolates,
you found that incidentally two chocolates remain in your pocket. So, you want to add these
chocolates into the packet which contains least number of chocolates. Write a C program which
can input the number of chocolates of each packet and display number of chocolates in each
packet after adding those left-over chocolates*/

#include<stdio.h>
int main()
{
    int x[10],n,i,min;
    scanf("%d",&n);
    for(i=0;i<n;i++){
        scanf("%d",&x[i]);
    }
    min=x[0];
    for(i=1;i<n;i++){
        if(min>x[i]){
            min = x[i];
        }
    }
   for(i=0;i<n;i++){
      if(x[i]==min){
            min = min+2;
        printf("%d ",min);
        continue;
       }
       else{
       printf("%d ",x[i]);
    }

   }
}

