/*7.Write a C program which will input some students marks into an array and determined what
percentage of students achieved close to average marks. (Here, close to average marks means
average-3 to average +3). */

#include<stdio.h>
#include<math.h>
int main()
{
    int n,i,x[100],s,c;
    float avg,p;
    printf("Enter the value of n: ");
    scanf("%d",&n);
    printf("Enter Some Students marks: \n");
    for (i=0;i<n;i++){
        scanf("%d",&x[i]);
    }
    s=0;
    for (i=0;i<n;i++){
		s = s+x[i];
    }
    avg= (float)s/n;
    c=0;
    for (i=0;i<n;i++){
    if(abs(avg-x[i])<=3){
    c++;
    }
    }
    p =(float)c/n;
   p = p*100;
   printf("%.2f percentage of students achieved close to average marks: ",p);
}
