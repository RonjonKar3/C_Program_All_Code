#include<stdio.h>
#include<math.h>
int main()
{
    int i,n,x,s=0;
    printf("Enter the value of n: ");
    scanf("%d",&n);
    for (i=0;i<n;i++){
         scanf("%d",&x);
    }
    for(i=1;i<x;i++){
        if(x%i==0){
            s=s+i;
        }
        if(s==x){
            printf("Perfect Number: %d",x);
        }
    }
}
