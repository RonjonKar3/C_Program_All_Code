/*6. Write a C program which can input some numbers and check how many of those marks are
greater than the last number*/

#include<stdio.h>
int main()
{
    int n,i,x[99],c=0;
    printf("Enter the value of n: ");
    scanf("%d",&n);
    printf("Enter some students marks: \n");
    for (i=0;i<n;i++){
        scanf("%d",&x[i]);
    }
    for (i=0;i<n;i++){
       if(x[i]>x[n-1]){
        c++;
       }
    }
    printf("%d numbers are greater than last number\n",c);
}

