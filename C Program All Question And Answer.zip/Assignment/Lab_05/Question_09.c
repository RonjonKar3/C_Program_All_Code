/*9. Write a C program which can input some numbers into an array and check how many numbers
are in between first and last number of that array.*/

#include<stdio.h>
int main()
{
    int i,n,x[100],c=0;
    printf("Enter the Value of n: ");
    scanf("%d",&n);
    printf("Enter some numbers: \n");
    for(i=0;i<n;i++){
        scanf("%d",&x[i]);
    }
    for (i=0;i<n;i++){
        if(x[0]<x[i] && x[n-1]>x[i] || x[0]>x[i] && x[n-1]<x[i] ){
            c++;
        }
    }
    printf("%d numbers are in between first and last number of that array",c);

}
