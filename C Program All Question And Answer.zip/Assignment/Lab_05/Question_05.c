/*5. Write a C program which input some integer into an array and find how many of those numbers
are greater than the middle-positioned number.[You may assume that user will input odd number
of values]*/

#include<stdio.h>
int main()
{
    int n,i,x[99],c=0;
    printf("Enter the value of n which will be odd number: ");
    scanf("%d",&n);
    for (i=0;i<n;i++){
        scanf("%d",&x[i]);
    }
    for (i=0;i<n;i++){
       if(x[i]>x[n/2]){
        c++;
       }
    }
    printf("%d numbers are greater than the middle-positioned number\n",c);
}


