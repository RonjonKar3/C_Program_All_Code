/*8. Write a C program which can input some students' age of a particular class into an array and 
check whether there is any teenager in that class.*/

#include<stdio.h>
int main()
{
    int n,i,x[100],c=0;
    printf("Enter the value of n: ");
    scanf("%d",&n);
    printf("Enter Some Students ages: \n");
    for (i=0;i<n;i++){
        scanf("%d",&x[i]);
    }
    for (i=0;i<n;i++){
       if (x[i]>=13 && x[i]<=19){
        c++;
       }
    }
    printf("There is %d teenager in that Class",c);
}
