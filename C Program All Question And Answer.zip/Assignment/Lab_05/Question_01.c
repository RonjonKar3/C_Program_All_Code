/*1. Write a C program to input some numbers into an array. Then find how many numbers of that 
array is greater than first element of the array and how many numbers of that array is smaller than 
first element of the array.*/

#include<stdio.h>
int main()
{
    int n,i,x[100],c=0,d=0;
    printf("Enter the value of n: ");
    scanf("%d",&n);
    for (i=0;i<n;i++){
        scanf("%d",&x[i]);
    }
    for (i=0;i<n;i++){
       if(x[i]>x[0]){
        c++;
       }
       else if(x[i]<x[0]){
        d++;
       }
    }
    printf("%d numbers are greater than first element\n",c);
    printf("%d numbers are smaller than first element",d);
}
