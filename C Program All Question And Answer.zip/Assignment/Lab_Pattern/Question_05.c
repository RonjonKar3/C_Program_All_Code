//Question_05

#include<stdio.h>
#include<math.h>
int main()
{
    int c,r,n;
    printf("Enter the Value of n: ");
    scanf("%d",&n);
    printf("The Pattern is:\n");
    for (r=1;r<=n;r++){
      for(c=1;c<=r;c++){
      printf("%d",c);
      printf(" ");
      }
      printf("\n");
    }
}

