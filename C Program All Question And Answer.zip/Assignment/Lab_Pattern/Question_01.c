//Question_01

#include<stdio.h>
#include<math.h>
int main()
{
    int c,r,n;
    printf("Enter the Value of n: ");
    scanf("%d",&n);
    printf("The Pattern is:\n");
    for (r=0;r<n;r=r+2){
      for(c=0;c<=r;c++){
      printf("*");
      printf(" ");
      }
      printf("\n");
    }
}


