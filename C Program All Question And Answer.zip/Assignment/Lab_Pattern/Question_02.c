//Question_02

#include<stdio.h>
int main()
{
    int c,r,n;
    printf("Enter the Value of n: ");
    scanf("%d",&n);
    printf("The Pattern is:\n");
    for (r=1;r<=n;r++){
        for(c=1;c<=n;c++){
            if(c%3==0){
                printf("-");
            }
                else {
                    printf("+");
                }
        }
        printf("\n");
    }

}

