//Question_03

#include<stdio.h>
int main()
{
    int c,r,n;
    printf("Enter the Value of n: ");
    scanf("%d",&n);
    printf("The Pattern is:\n");

    for (r=0;r<n;r++){
        for(c=0;c<=r;c++){
            if(c>2){
                printf("-");
            }
                else {
                    printf("+");
                }
        }
        printf("\n");
    }

}
