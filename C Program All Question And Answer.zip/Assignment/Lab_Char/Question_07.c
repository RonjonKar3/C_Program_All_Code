/*7. Write a C program which can input some lowercase letters and display which vowels
appear most*/

#include <stdio.h>

int main()
{
    char x[200];
    int p ,a=0, e=0, i=0, o=0, u=0, m,n;
    scanf("%d",&n);
    for(m=0; m<n; m++){
        scanf(" %c",&x[m]);
    }
    for(m=0; m<n; m++){
        if(x[m] =='a')
        {
            a++;
        }
        if( x[m]=='e'){
            e++;
        }
        if(x[m]=='i'){
            i++;
        }
        if(x[m]=='o'){
            o++;
        }
        if(x[m]=='u'){
            u++;
        }
    }
    if(a>=e && a>=i && a>=o && a>=u){
        printf("a appears the most\n");
    }
     if(e>=a && e>=i && e>=o && e>=u){
        printf("e appears the most\n");
    }
     if(i>=e && i>=a && i>=o && i>=u){
        printf("i appears the most\n");
    }
     if(o>=e && o>=i && o>=a && o>=u){
        printf("o appears the most\n");
    }
     if(u>=e && u>=i && u>=o && u>=a){
        printf("u appears the most\n");
    }

}
