/*5. Write a C program which can input some letters and display how many uppercase vowels
and how many lowercase vowels exist.*/

#include<stdio.h>
int main()
{
    char x;
    int i,n,c,d;
    printf("Enter the Value of n: ");
    scanf("%d",&n);
    printf("Enter %d Vowels:\n",n);
    c=d=0;
    for(i=0;i<n;i++){
        scanf(" %c",&x);

     if(x=='A' || x=='E' || x=='I' || x=='O' || x=='U'){
        c++;
     }
     if(x=='a' || x=='e' || x=='i' || x=='o' || x=='u'){
        d++;
     }
    }
    printf("Uppercase vowels: %d\n",c);
    printf("Lowercase vowels: %d\n",d);
}
