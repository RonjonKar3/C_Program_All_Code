/*4. Write a C program which can input some letters into an array and change each uppercase
letter to it�s next uppercase letter keeping lowercase letter unchanged.*/

#include<stdio.h>
int main()
{
    char x[100],y,z;
    int n,i;
    printf("Enter the Value of n: ");
    scanf("%d",&n);
     printf("Enter %d Alphabet:\n",n);
    for(i=0;i<n;i++){
       scanf(" %c",&x[i]);
    }
    for(i=0;i<n;i++){
     if(x[i]>='A' && x[i]<'Z'){
        y=x[i]+1;
    printf("Next Uppercase letter:%c\n",y);
     }
     if(x[i]>='a' && x[i]<='z'){
        z=x[i];
        printf("Lowercase: %c\n",z);
     }
    }

}
