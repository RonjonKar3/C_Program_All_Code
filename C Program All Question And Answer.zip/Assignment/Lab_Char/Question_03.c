/*3. Write a C program which can input some letters and display ratio between uppercase and
lowercase letters.*/

#include<stdio.h>
int main()
{
    char x;
    int n,i,c,d;
    printf("Enter the Value of n: ");
    scanf("%d",&n);
    printf("Enter %d Alphabet:\n",n);
    c=d=0;
    for(i=0;i<n;i++){
       scanf(" %c",&x);
     if(x>='A'&&x<='Z'){
        c++;
    }
     else if(x>='a'&&x<='z'){
        d++;
    }
    }

    printf("Ratio= %.2f",(float)c/d);
}

