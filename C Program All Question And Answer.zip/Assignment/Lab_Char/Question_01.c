/*1. Write a C program which can input a character and display whether it is an uppercase
letter, lowercase letter or digit.*/

#include<stdio.h>
int main()
{
    char x;
    printf("Enter a Character:\n");
    scanf("%c",&x);
    if(x>='A' && x<='Z'){
        printf("It is a Uppercase Alphabet");
    }
    else if(x>='a' && x<='z'){
        printf("It is a Lowercase Alphabet");
    }
     else if(x>='0' && x<='9'){
        printf("It is a Digit");
    }
    else{
        printf("It is not an Alphabet or a Digit");
    }
}
