/*2. Write a C program which can input three lower case letters and display whether any
duplicate exists or not*/

#include<stdio.h>
int main()
{
    char x,y,z;
    printf("Enter three Lowercase Character:\n");
    scanf(" %c %c %c",&x,&y,&z);
    if(x==y || x==z || y==z){
        printf("Duplicate exists");
    }
    else{
        printf("Duplicate does not exists");
    }
}
