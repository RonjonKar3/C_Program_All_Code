/*6. Write a C program which can input some letters and interchange each one case.*/

#include<stdio.h>
int main()
{
    char x,y,z;
    int i,n;
     printf("Enter the Value of n: ");
     scanf("%d",&n);
    for(i=0;i<n;i++){
     printf("Enter Letter Number %d: ",i+1);
     scanf(" %c",&x);
     if(x>='A' && x<='Z'){
        y=x+32;
        printf("Lowercase Letter: %c\n",y);
     }
     if(x>='a' && x<='z'){
       y=x-32;
       printf("Uppercase Letter: %c\n",y);
     }
    }
}
