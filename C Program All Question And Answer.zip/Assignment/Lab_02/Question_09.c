/*9. Write a C program which can input four integer numbers that indicated 2 points in a 2D co-ordinate 
system. Display whether two points falls into same axis.*/

#include<stdio.h>
int main(){
int x1,y1,x2,y2;
scanf("%d%d%d%d",&x1,&y1,&x2,&y2);
if(x1==0 && x2==0){
    printf("Two point fall into same axis");
}
else if(y1==0 && y2==0){
    printf("Two point fall into same axis");
}
else {
    printf("Two point does not fall into same axis");
}
return 0;
}
