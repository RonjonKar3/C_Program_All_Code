/*10. Write a C program which can input four integer numbers that indicated 2 points in a 2D co-ordinate 
system. Display whether two points falls into same quadrant.*/

#include<stdio.h>
int main()
{
    int x1,x2,y1,y2;

    scanf("%d %d %d %d",&x1,&y1,&x2,&y2);
    if(x1>0 && x2>0 && y1>0 && y2>0)
    {
        printf("Two points fall into same quadrant");
    }
    else if(x1<0 && y1>0 && x2<0 && y2>0){
        printf("Two points fall into same quadrant");
    }
    else if(x1<0 && y1<0 && x2<0 && y2<0){
        printf("Two points fall into same quadrant");
    }
    else if(x1>0 && y1<0 && x2>0 && y2<0){
        printf("Two points fall into same quadrant");
    }
    else {
        printf("Two points do not fall into same quadrant");
    }
    return 0;
}

