/*13. Write a C program which can input three numbers and display the maximum number*/

#include<stdio.h>
int main(){
int a,b,c;
scanf("%d%d%d",&a,&b,&c);
if((a>b)&& (a>c)){
    printf("a is the maximum");
}
else if((b>a) &&(b>c)){
    printf("b is the maximum");
}
else{
    printf("c is the maximum");
}
return 0;
}
