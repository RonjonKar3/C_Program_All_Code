/*8. Write a C program which can input two numbers indicating a point in a 2D co-ordinate and determine 
its quadrant.*/

#include<stdio.h>
int main(){
int Point1,Point2;
scanf("%d%d",&Point1,&Point2);
if(Point1>0 && Point2>0){
    printf("The Point is Located in the 1st Quadrant");
}
else if(Point1>0 && Point2<0){
    printf("The Point is Located in the 2nd Quadrant");
}
else if(Point1<0 && Point2<0){
    printf("The Point is Located in the 3rd Quadrant");
}
else if(Point1<0 && Point2>0){
    printf("The Point is Located in the 4th Quadrant");
}
else if(Point1==0 && Point2==0)
printf("Origin")
}
else if (Point2==0){
    printf("X Axis");
}
else if (Point1==0){
    printf("Y Axis");
}
return 0;
}

