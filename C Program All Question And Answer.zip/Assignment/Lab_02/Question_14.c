/*14. Write a C program which can input three numbers and display the median number*/

#include<stdio.h>
int main(){
int a,b,c;
scanf("%d%d%d",&a,&b,&c);
if(a>b){
    printf("c is the median");
}
else if(b>c){
    printf("a is the median");
}
else if(c>a){
    printf("b is the median");
}
return 0;
}

