/*15. Write a C program which can input three numbers and display difference between highest and lowest*/

#include<stdio.h>
int main(){
int a,b,c,Ans;
scanf("%d%d%d",&a,&b,&c);

if((a>b) && (b>c)){
  Ans= a-c;
  printf("Difference between highest and lowest Value=%d\n",Ans);
}
else if((a<b) && (b<c)){
  Ans= c-a;
  printf("Difference between highest and lowest Value=%d\n",Ans);
}
else if((b>a) && (a>c)){
  Ans= b-c;
  printf("Difference between highest and lowest Value=%d\n",Ans);
}
else if((b<a) && (a<c)){
  Ans= c-b;
  printf("Difference between highest and lowest Value=%d\n",Ans);
}
else if((a>c && (c>b))){
  Ans= a-b;
  printf("Difference between highest and lowest Value=%d\n",Ans);
}
else if((a<c && (c<b))){
  Ans= b-a;
printf("Difference between highest and lowest Value=%d\n",Ans);
}
return 0;
}

