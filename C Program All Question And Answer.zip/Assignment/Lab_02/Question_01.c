/*1. Write a C program which can input three integers indicating three angles of triangle and display any 
of following three - triangle is an equilateral triangle, triangle is a right-angle triangle or not any of 
those two types.*/

#include<stdio.h>
int main(){
int a,b,c,sum;
scanf("%d%d%d",&a,&b,&c);
sum=a+b+c;
if(sum<0 || sum>180 || sum<180){
    printf("Error");
}
else if (a==60 && b==60 && c==60)
{
    printf("This is an equilateral triangle");
}
else if (a==90 || b==90 || c==90)
{
    printf("This is an right angle triangle");
}
else
{
    printf("Not an equilateral triangle or right angle triangle");
}
}

