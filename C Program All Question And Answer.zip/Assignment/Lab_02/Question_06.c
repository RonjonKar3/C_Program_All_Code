/*6. Write a C program which can input electricity usage of a house and display the bill amount 
considering following conditions: If usage is less than 250 then bill is 4 taka per unit. If usage is less 
than 500 then bill is 6 taka per unit. If usage is above 500 then bill is 9 taka per unit*/

#include<stdio.h>
#include<math.h>
int main(){
int a,b;
scanf("%d",&a);
if(a>0 && a<=250){
        b=a*4;
}
else if(a<=500){
        b=250*4+(a-250)*6;
}
else if(a>500){
        b=250*4+ 250*6+(a-500)*9;
}
printf("Bill: %d\n",b);
return 0;
}
