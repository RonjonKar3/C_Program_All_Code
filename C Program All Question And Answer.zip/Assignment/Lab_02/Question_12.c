/*12. Write a C program which can input a number and display check divisibility by 7 and 13. Provide 
message � �Divisible by both�, �Divisible by one�, �Divisible by both none�.*/

#include<stdio.h>
int main() {
int number,7,13;

printf("Enter the number:\n");
scanf("%d",&number);

if(number%7==0 && number%13==0) {
	    printf("Divisible by both");
}
else if((number%7==0 && number%13!=0)||(number%13==0 && number%7!=0)) {
        printf("Divisible by one");
}
else{
		printf("Divisible by both none");
	}
	return 0;
}

