/*2. Write a C program which can input three number indicating a, b, c of quadratic equation and display 
whether two rational root available for that equation.*/

#include <stdio.h>
#include <math.h>

int main()
{
   int a,b,c,d;
   float x,y;

   scanf("%d%d%d",&a,&b,&c);
   d=b*b-4*a*c;
   if(d==0)
   {
     printf("Both roots are equal");
     x=-b/(2.0*a);
     y=x;
     printf("Root1= %f\n",x);
     printf("Root2= %f\n",y);
   }
   else if(d>0)
	{
	   printf("Both roots are real");
	   x=(-b+sqrt(d))/(2*a);
	   y=(-b-sqrt(d))/(2*a);
	   printf("%f\n",x);
	   printf("%f\n",y);
	}
	else
	    printf("Root are imaginary No Solution");
}

