/*11. Write a C program which can input two number and display whether one is divisible by one. Provide 
message � �Only one is divisible by another�, �Both is divisible by each other�, �None is divisible by 
other.*/

#include<stdio.h>
int main() {
    int a,b;
    printf("Enter two numbers:\n");
    scanf("%d %d",&a,&b);
    if(a%b==0 && b%a==0){
        printf("Both is divisible by each other");
    }
    else if(a%b==0 && b%a!=0 || a%b!=0 && b%a==0){
            printf("Only one is divisible by another");
    }
    else {
        printf("None is divisible by other");
    }
    return 0;
}
