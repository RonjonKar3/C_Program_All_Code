/*5. Write a C program which can a four-digit number and display difference between numbers consists of
first two digits and of last two digits. As example, if input is 4578 then output will be 33 because 78-45
= 33.*/

#include<stdio.h>
int main()
{
    int n,first2digit,last2digit,digit1,digit2,digit3,digit4,diff;
    printf("Enter any 4 digits number:\n");
    scanf("%d",&n);
    digit1 = (n/1000)%10;
    digit2 = (n/100)%10;
    digit3 = (n/10)%10;
    digit4 = n%10;
    first2digit=digit1*10+digit2;
    last2digit= digit3*10+digit4;
    diff = last2digit-first2digit;
    printf("difference between first two digits and last two digits = %d",diff);
    return 0;
}

