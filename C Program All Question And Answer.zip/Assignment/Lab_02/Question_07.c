/*7. Write a C program which can input two numbers indicating term1 and term2 marks of a student; 
display in which exam the student gets higher marks.*/

#include<stdio.h>
int main(){
int a,b,marks;
scanf("%d%d",&a,&b);

if(a>b){
    printf("Term 1 exam the student gets higher marks");
}
else if(a<b){
    printf("Term 2 exam the student gets higher marks");
}
else{
     printf("Both Exam the students get same marks");
}
return 0;
}
