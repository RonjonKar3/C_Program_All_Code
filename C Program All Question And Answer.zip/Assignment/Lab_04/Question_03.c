/*3. Write a C program which can input some 2D points and the number of points in each quadrant.*/

#include<stdio.h>
int main()
{
    int a,x,y,n,F,S,T,U;
    scanf("%d",&n);
    F=0;
    S=0;
    T=0;
    U=0;
    for (a=1;a<=n;a++){
            scanf("%d%d",&x,&y);
        if (x>0 && y>0){
            F++;
        }
        else if (x<0 && y>0){
            S++;
        }
         else if (x<0 && y<0){
            T++;
        }
         else if (x>0 && y<0){
            U++;
        }

    }
    printf("First Quadrant: %d\n",F);
    printf("Second Quadrant: %d\n",S);
    printf("Third Quadrant: %d\n",T);
    printf("Fourth Quadrant: %d",U);
}
