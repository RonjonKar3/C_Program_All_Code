/*4. Write a C program which can input some country�s population and display average population of 
those countries.*/

#include<stdio.h>
int main()
{
    int x,s,n,a;
    float avg,c;
    printf("Enter the Number of country:\n");
    scanf("%d",&n);
    c=0;
    s=0;
    printf("Enter the number of  Population:\n");
    for (a=1;a<=n;a++){
        scanf("%d",&x);
        s=s+x;
        c++;
    }
    avg= s/c;
    printf("Average population of those countries:%f",avg);
}
