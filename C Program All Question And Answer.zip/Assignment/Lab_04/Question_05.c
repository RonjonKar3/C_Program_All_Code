/*5. Write a C program which can input some students marks and display average marks who passed in 
the exam and average marks who do not passed in the exam. [Passed mark is 60]*/

#include<stdio.h>
int main()
{
    int a,n,x,c,d,s,t;
    float a1,a2;
    printf("Enter Some Students Marks: ");
    scanf("%d",&n);
    c=0;
    d=0;
    s=0;
    t=0;
   for (a=1;a<=n;a++){
      scanf("%d",&x);
      if (x>=60 && x<=100){
        c++;
        s=s+x;
      }
      else if(x<60){
        d++;
        t=t+x;
      }
}
      a1=(1.0*s)/c;
      a2=(1.0*t)/d;
   printf("Average of passing students: %.2f\n",a1);
   printf("Average of failing students: %.2f",a2);
}


