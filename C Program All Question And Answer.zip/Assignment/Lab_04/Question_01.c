/*1. Write a C program which can input some persons� ages and display how many of them are teenager*/

#include<stdio.h>
int main()
{
    int a,x,n,c;
    scanf("%d",&n);
    c=0;
    for(a=1;a<=n;a++){
        scanf("%d",&x);
        if (x>=13 && x<=19){
        c++;
        }
    }
    printf("%d",c);
}
