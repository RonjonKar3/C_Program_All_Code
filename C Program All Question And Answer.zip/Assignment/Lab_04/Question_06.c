/*6. Write a C program which can input some 2D points and the number of points falls into 45*
line and how many falls into 135* line. [Green one is 45* line and black one is 135* line]*/

#include <stdio.h>
int main() {
    int i,n,x[100],y[100];
    printf("Enter The Value of n\n");
    scanf("%d",&n);

    for (i=0;i<n;i++){
    printf("Enter 2D Point %d: \n",i+1);
    scanf("%d %d", &x[i], &y[i]);
    }
    for (i=0;i<n;i++){
    if(x[i]==0 &&y[i]==0){
        printf("Both Green & Black\n");
    }
    else if(x[i]==y[i]){
        printf("Green\n");
    }
    else if ((abs(x[i]) == abs(y[i])) && (x[i]<0 || y[i]<0)){
        printf("Black\n");
    }
    else{
        printf("Not green Not Black\n");
    }
    }

    return 0;
}


