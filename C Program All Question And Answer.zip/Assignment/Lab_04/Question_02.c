/*2. Write a C program which can input some persons� ages and display number of people in each 
category. There are three categories � Child (Up to 12 years), Teenager (13-19 Years) and senior 
citizen (65 and 65+)*/

#include<stdio.h>
int main ()
{
    int a,x,n,C,T,S;
    scanf("%d",&n);
    C=0;
    T=0;
    S=0;
    for (a=1;a<=n;a++){
       scanf("%d",&x);
       if (x<=12){
            C++;
    }
       else if(x>=13 && x<=19){
            T++;
       }
     else if(x>=65){
            S++;
       }
    }
    printf("Child: %d\n",C);
    printf("Teenage: %d\n",T);
    printf("Senior Citizen: %d\n",S);
}
