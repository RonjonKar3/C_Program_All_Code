//5. A newborn baby normally sleeps a lot. If baby�s sleep time is more than double of awake time it is
//called �Over sleepy infant�. If sleep time is in range of equal to double of awake time then it is called
//�Normal sleepy infant�. If sleep time is less than awake time then it is called �Less sleepy infant�.
//Write a C program which can input a newborn�s sleep time and awake time (in integers) and display
//what type of sleep pattern he/she maintains.

#include<stdio.h>
#include<math.h>
int main()
{
int Sleep,Awake;
printf("Enter Sleep & Awake time a newborn baby:\n");
scanf("%d%d",&Sleep,&Awake);
if (Sleep > Awake){
    printf("Over sleepy infant");
}
else if (Sleep == Awake){
    printf("Normal sleepy infant");
}
else {
    printf("Less sleepy infant");
}
return 0;
}
