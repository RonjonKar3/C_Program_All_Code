//10. Suppose you purchased a lot of chocolates and want to distribute those with your cousins. You want
//to give them as many chocolates as possible but also want to give each one the same number of
//chocolates. Write a C program which can input the number of chocolates you bought and number of
//cousins you have and display how many chocolates will get by each of your cousin and whether any
//chocolates will remain after distribution.
#include<stdio.h>
int main()
{
    int ch,c,i,n;
    scanf("%d %d",&ch,&c);
    i = ch/c;
    n = ch%c;
    printf("Each of your cousin will get %d\n",i);
    printf("%d chocolates will remain after distribution",n);
    return 0;
}
