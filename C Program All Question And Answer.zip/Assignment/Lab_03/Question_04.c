//4. Tashfin's uncle Tahseen recently went abroad. On his return he brought a lot of chocolates for his
//nephews and nieces who are eight in number. Tahseen wants to distribute these chocolates evenly
//among all his nephews and nieces. However before distributing he will keep five chocolates for his
//brothers and sister. If the number of remaining chocolates cannot be evenly distributed among his
//eight nephews and nieces, then rest of those remaining chocolates will be kept for Tahseen's
//brothers and sister. Develop a C program which will take as input the number of chocolates Tahseen
//brought, and display how many chocolates will Tahseen's each nephew/nieces get. Also, find and
//display how many chocolates will be for Tahssen's brothers and sisters.
#include<stdio.h>
int main()
{
    int n;
    scanf("%d",&n);
    n = n - 5;
    if(n%8==0){
            n = n/8;
        printf("Tahseen's each nephew/nieces get %d chocolates\n",n);
        printf("Tahssen's brothers and sisters will get 5 chocolates");
    }
    else {
            n = n+5;
    printf("Tahssen's brothers and sisters will get %d",n);
    }

}
