//8. Nusaiba is child who just learn to crawl. However, she cannot crawl continuously a large distance.
//After every 3 feet of crawling, she needs to rest for a while. Write a C program which input distance of
//Nusaiba�s crawling and display number of times she takes rest to crawl this distance.

#include<stdio.h>
#include<math.h>
int main()
{
int a,b;
printf("Enter the distance of Nusaiba's crawling:\n");
scanf("%d",&a);
b= floor(a/3.0);
printf("She takes rest to crawl this distance '%d times'.",b);
return 0;
}

