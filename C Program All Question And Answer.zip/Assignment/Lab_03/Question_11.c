/*11. Suppose an elevator can accommodate m number of people and there are n people in the queue.
Write a C program to input integers indicating those m and n and display how many times the
elevator operates to serve all of those people in queue.*/

#include<stdio.h>
#include<math.h>
int main()
{
    int m,n;
    float num;
    scanf("%d %d",&m,&n);
    num = (float)n/m;
    num = ceil(num);
    printf("%.1f times the elevator operates to serve all",num);
    return 0;

}
