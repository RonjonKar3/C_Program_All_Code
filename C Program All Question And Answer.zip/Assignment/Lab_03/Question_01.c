//1. Suppose you have two water containers – one is sphere shaped and another is cubic shaped. Write a
//C program which can input two integers indicating radius of a sphere-shaped container and length of
//sides of the cubic shaped container; display in which type of container you can store more water.
//[Volume of a sphere is: 4/3×π×r3; volume of a cube: a3]

#include<stdio.h>
#include<math.h>
int main()
{
    int r,a;
    float SphereShaped, CubicShaped;
    printf("Enter the value radius of a sphere-shaped container and length of sides of the cubic shaped container:\n");
    scanf("%d%d",&r,&a);
    SphereShaped= (4/3)*3.1416*r*r*r;
    CubicShaped= a*a*a;
    if (SphereShaped > CubicShaped){
        printf("Sphere Shaped Container can store more water");
    }
    else if (SphereShaped < CubicShaped){
        printf("Cubic Shaped Container can store more water");
    }
    else if (SphereShaped == CubicShaped){
        printf("Two Container can store Equal Water");
}
return 0;
}
