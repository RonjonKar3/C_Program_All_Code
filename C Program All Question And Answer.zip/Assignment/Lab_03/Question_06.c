//6. Tashfin�s cousin bought some books for him where the shopkeeper give one coupon with each book
//and said that if he returns those coupons then for every three coupons he can get one chocolates and
//for each coupons he can get one chewing gum. However Tashfin is more interested in chocolates
//than chewing gum. Write a C program which can input number of books Tasfin�s cousin bought and
//display how many chocolates and chewing gum he can get by returning those coupons maintaining
//Tashfin�s choice.

#include<stdio.h>
int main()
{
    int a,c,g;
    scanf("%d",&a);

        c = a/3;
        g = a%3;
        printf("Tasfin�s cousin can get %d chocolates\n",c);
        printf("Tasfin�s cousin can get %d chewing gums",g);
        return 0;

}
