//2. Write a C program which can input an integer number from the user and display immediate next odd number.

#include<stdio.h>
#include<math.h>
int main()
{
int Marks, NextOdd;
scanf("%d",&Marks);

if(Marks%2==0){
    NextOdd=Marks+1;
}
else{
   NextOdd=Marks+2;
}
printf("The Next Odd Mark is=%d",NextOdd);
return 0;
}

