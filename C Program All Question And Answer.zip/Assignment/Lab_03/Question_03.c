//3. Write a C program which takes an integer as user input that indicates the annual salary of a person.
//The program should find and display the monthly salary of that person.

#include<stdio.h>
#include<math.h>
int main()
{
int AnnualSalary,MonthlySalary;
printf("Entre the annual salary of a person:\n");
scanf("%d",&AnnualSalary);
MonthlySalary= AnnualSalary/12;
printf("The monthly salary of the person is %d",MonthlySalary);
return 0;
}
