//7. A car rental company charges 20 taka for every kilometer of travel. (It charges full 20 taka for any
//fractional km). It also charges 2 taka for every minute of waiting. Write a C program which can input a
//fractional number indicating distance travel and an integer number indicating waiting time in minutes.
//Display the total bill for that ride

#include<stdio.h>
#include<math.h>
int main()
{
    float a;
    int b,c,d,bill;
    scanf("%f",&a);
    scanf("%d",&b);
    a= ceil(a);
    c= a*20;
    d= b*2;
    bill=c+d;

    printf("%d",bill);
    return 0;
}
