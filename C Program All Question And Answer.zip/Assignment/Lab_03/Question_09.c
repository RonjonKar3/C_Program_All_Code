//9. You have bought a large number of cubic shape marbles and //want to store them in a cube shape box. Write a C program //which can input length marbles and also length of the box and //display how many marbles can be stored in that box.

#include<stdio.h>
#include<math.h>
int main()
{
    int B,M,Total;
    printf("Entre the length of the box and also 7length marbles :\n");
    scanf("%d%d",&B,&M);
    Total= ceil(B/M);
    printf("%d marbles can be stored in that box",Total);
    return 0;

}
