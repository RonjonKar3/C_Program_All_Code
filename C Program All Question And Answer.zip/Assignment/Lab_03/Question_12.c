/*12. In new COVID protocol in elevator queue every person should maintain a three feet distance from
another person. If a corridor in front of the elevator is n feet long then how many people can gather
for the queue. Write an appropriate C program for this.
*/

#include<stdio.h>
int main()
{
    float n;
    int num;
    scanf("%f",&n);
    num = n/3.0;
    printf("%d peoples can gather",num);
    return 0;
}

